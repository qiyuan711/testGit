from editor    import Editor

